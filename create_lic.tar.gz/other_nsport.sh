for i in `tail -n +2 /etc/cav_controller.conf | cut -d '|' -f 1 `;do grep "portNetstorm" /home/netstorm/$i/webapps/sys/config.ini;done > /tmp/port.txt

tail -n +2 /etc/cav_controller.conf | cut -d '|' -f 1 >> /tmp/controller.txt

#tail -1 /home/netstorm/$i/.rel/version.dat | cut -d '|' -f 1 >> /tmp/BuildVersion.txt
