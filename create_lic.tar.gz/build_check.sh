num=`sed -n 1p /tmp/build_check.txt`

tail -1 /home/netstorm/$num/.rel/version.dat | cut -d '|' -f 1 | awk '{print $1}' > /tmp/cp_bld_chck.txt
sed -i 1d /tmp/build_check.txt
