
for i in `tail -n +2 /etc/cav_controller.conf | cut -d '|' -f 1 `
do
	mkdir /home/netstorm/$i/.license/
done
