

tail -n +2 /etc/cav_controller.conf | cut -d '|' -f 1 > /tmp/controller_name.txt
