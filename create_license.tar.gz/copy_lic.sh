

num=`sed -n 1p /tmp/controller_name.txt`
cp /tmp/license.nl1 /home/netstorm/$num/.license
sed -i 1d /tmp/controller_name.txt
