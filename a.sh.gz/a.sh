declare -a var_name=(1 2 3 4 5 6)
echo ${var_name[2]}

